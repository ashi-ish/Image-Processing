% Function for LZW compression
function [compressed_data, dictionary] = lzw_compress(data)
    % Initialize dictionary with 256 initial values (0 to 255)
    dictionary = cell(256, 1);
    for i = 0:255
        dictionary{i + 1} = num2str(i);
    end
    
    % Initialize variables
    current_code = '';
    compressed_data = [];
    
    % Iterate over each element in data
    [rows, cols] = size(data);
    for row = 1:rows
        for col = 1:cols
            next_char = num2str(data(row, col));
            
            % Construct the new code with a hyphen between characters
            if ~isempty(current_code)
                new_code = strcat(current_code, '-', next_char);
            else
                new_code = next_char;
            end
            
            % If the new code is in the dictionary, update current_code
            if ismember(new_code, dictionary)
                current_code = new_code;
            else
                % Write the code for the current_code to compressed_data
                compressed_data = [compressed_data getCode(dictionary, current_code)];
                
                % Add the new code to the dictionary
                dictionary{end + 1} = new_code;
                
                % Reset current_code   
                current_code = next_char;
            end
        end
    end
    
    % Write the last code to compressed_data
    if ~isempty(current_code)
        compressed_data = [compressed_data getCode(dictionary, current_code)];
    end
end

% Helper function to get code from dictionary
function code = getCode(dictionary, key)
    code = find(ismember(dictionary, key)) - 1;
end
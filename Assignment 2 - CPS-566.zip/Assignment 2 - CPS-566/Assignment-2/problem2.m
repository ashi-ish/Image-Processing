% Clear all variables, close all figures, and clear the command window
clearvars;
close all;
clc;

% Read the original image
original_image = imread('udayton.jpg');

% Convert the original image to grayscale
grayscale_image = rgb2gray(original_image);

% Display the original grayscale image
figure, imshow(grayscale_image), title("Original Grayscale Image");

% Print a sample of the grayscale image
disp('Grayscale Image (10x10 sample):');
disp(grayscale_image(1:10, 1:10));

% Read compressed data from file
compressed_data = read_compressed_data('compressed_image.lzw');

% Read dictionary values from file
dictionary = read_dictionary('dictionary_values.txt');

% Obtain the dimensions of the original grayscale image
[image_height, image_width] = get_image_dimensions('udayton.jpg');

% Decompress the image
[decompressed_image, decompressed_values] = lzw_decompress(compressed_data, dictionary, image_height, image_width);

% Convert the decompressed image to uint8
decompressed_image = uint8(decompressed_image);

% Print a sample of the decompressed image
disp('Decompressed Image (10x10 sample):');
disp(decompressed_image(1:10, 1:10));

% Display the decompressed image
figure, imshow(decompressed_image), title("Decompressed Image");

% Function to read compressed data from file
function compressed_data = read_compressed_data(filename)
    fid = fopen(filename, 'rb');
    compressed_data = fread(fid, '*ubit32')';  % Read data in 32-bit format
    fclose(fid);
end

% Function to read dictionary values from file
function dictionary = read_dictionary(filename)
    fid = fopen(filename, 'rt');
    dictionary_values = textscan(fid, 'Key: %d, Value: %s');
    fclose(fid);
    dictionary = dictionary_values{2};  % Extract dictionary values
    % Split dictionary values into tokens separated by hyphen
    for index = 1:length(dictionary)
        dictionary{index} = split(dictionary{index}, '-');
    end
end

% Function to obtain image dimensions
function [height, width] = get_image_dimensions(filename)
    image_info = imfinfo(filename);
    height = image_info.Height;
    width = image_info.Width;
end
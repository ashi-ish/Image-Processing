clear all;
close all;
clc;

I = imread('Nature.png');
K = rgb2gray(I);
J = imnoise(K, 'salt & pepper', 0.5);

% Define convolution kernels
h1 = 1/9 * ones(3,3);
h2 = 1/25 * ones(5,5);
h3 = 1/49 * ones(7,7);

% Apply padding to handle boundary pixels
pad_size = floor(size(h3, 1) / 2);
‎Read more
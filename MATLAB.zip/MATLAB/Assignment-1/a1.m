clear all;
close all;
clc;

I = imread('image.png');
K = rgb2gray(I);
J = imnoise(K, 'salt & pepper', 0.5);

% Define convolution kernels
h1 = 1/9 * ones(3,3);
h2 = 1/25 * ones(5,5);
h3 = 1/49 * ones(7,7);

% Apply padding to handle boundary pixels
pad_size = floor(size(h3, 1) / 2);
J_padded = padarray(J, [pad_size, pad_size], 'replicate');

% Apply median filtering using convolution with provided kernels
c1 = applyMedianFilter(J_padded, h1);
c2 = applyMedianFilter(J_padded, h2);
c3 = applyMedianFilter(J_padded, h3);

% Remove padding from filtered images
c1 = c1(pad_size+1:end-pad_size, pad_size+1:end-pad_size);
c2 = c2(pad_size+1:end-pad_size, pad_size+1:end-pad_size);
c3 = c3(pad_size+1:end-pad_size, pad_size+1:end-pad_size);

subplot(2, 3, 1); imshow(I); title('Original Image');
subplot(2, 3, 2); imshow(K); title('Gray Image');
subplot(2, 3, 3); imshow(J); title('Noise added Image');
subplot(2, 3, 4); imshow(uint8(c1)); title('3x3 Image (Median Filter)');
subplot(2, 3, 5); imshow(uint8(c2)); title('5x5 Image (Median Filter)');
subplot(2, 3, 6); imshow(uint8(c3)); title('7x7 Image (Median Filter)');

% Function to apply median filtering using convolution
function filteredImage = applyMedianFilter(image, kernel)
    [rows, cols] = size(image);
    [kRows, kCols] = size(kernel);
    pad = floor(kRows / 2);
    filteredImage = zeros(size(image));
    for i = pad+1:rows-pad
        for j = pad+1:cols-pad
            % Extract neighborhood
            neighborhood = image(i-pad:i+pad, j-pad:j+pad);
            % Apply median filtering
            filteredImage(i, j) = median(neighborhood(:));
        end
    end
end
function [matched_img] = histogram_match(src_img, contrast_img, L)

    % Compute histograms
    src_hist = imhist(src_img, L);
    contrast_hist = imhist(contrast_img, L);

    % Matrix created with zero's to enter the integers
    matrix_created = zeros(256, 1, "uint8");

    % Compute cumulative distribution functions (CDFs)
    % CDF = Cumulative Sum of image / number of elements of image
    src_cdf = cumsum(src_hist) / numel (src_img);
    contrast_cdf = cumsum(contrast_hist) / numel(contrast_img);

    % Initialize the mapping function
    %mapping = zeros(1, L);

    % Perform histogram matching
    for i = 1:L
        % Calculate the difference of elements of source image and contrast image 
        diff = abs(src_cdf(i) - contrast_cdf);
        [~, index] = min(diff);
        % the differece is assigned to the matrix
        matrix_created(i) = index - 1;
    end

    % Apply the mapping to the target image
    %matched_img = uint8(mapping(double(reference_img) + 1)); % Adjust indices for 1-based indexing
    matched_img = matrix_created(double(src_img) + 1);
end
clear all;
close all;
clc;

img = imread('puppy.png');
source_image = rgb2gray(img);

img2 = imread('Contrast.png');
template_image = rgb2gray(img2);

output_image = histogram_match(source_image, template_image, 256);

subplot(2,3,1), imshow(source_image);
title('Source Image');

subplot(2,3,2), imshow(template_image);
title('Template Image');

subplot(2,3,3), imshow(output_image);
title('Output Image');

subplot(2,3,4), imhist(source_image);
title('Source Histogram');

subplot(2,3,5), imhist(template_image);
title('Template Histogram');

subplot(2,3,6), imhist(output_image);
title('Output Histogram');
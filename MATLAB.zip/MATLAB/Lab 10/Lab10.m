clear all;
close all;
clc;

img = imread('udayton.jpg');
figure, imshow(img),title('Original Image');

img_reduced = imresize(img, 0.5);
figure, imshow(img_reduced), title('Reduced size Image');

img_magnified = imresize(img, 2);
figure, imshow(img_magnified), title('Magnified Image');

img_rotate_bilinear = imrotate(img, 35, 'bilinear');
figure, imshow(img_rotate_bilinear), title('Rotated Image bilinear');

img_rotate_nearest = imrotate(img, 35,"nearest");
figure, imshow(img_rotate_nearest), title('Rotated Image Nearest');

img_rotate_bicubic = imrotate(img, 35, 'bicubic');
figure, imshow(img_rotate_bicubic), title('Rotated Image Bicubic');

[h,w,c] = size(img);
r_img = zeros(h,w,c);
r_img(: , w:-1:1, :) = img(:, 1:w, :);
r_img = uint8(r_img);
figure, imshow(r_img), title('Reflected Image');

translate_img = imtranslate(img, [50,50]);
figure, imshow(translate_img), title('Translated Image');

tform = maketform('affine', [3 0 0; -.5 2 0; 0 0 1]);
tran_img = imtransform(img, tform);
figure, imshow(tran_img), title('Affine Transform');

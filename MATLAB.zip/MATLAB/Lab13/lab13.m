clear all;
close all;
clc;

I = imread('fingerprint.jpg');
figure, imshow(I);
figure, imhist(I);
T = graythresh(I);
I2 = im2bw(I,T);
figure, imshow(I2);

im = imread('fingerprint.jpg');
im = rgb2gray(im);
figure, imshow(im);

I = im(300);
T = randsample(I,1);
TO = -1.0;

while abs(T - double(TO)) > 10^-9
    TO = T;
    g1 = I<=T;
    g2 = I>T;
    mean1 = sum(I(g1))/sum(g1);
    mean2 = sum(I(g2))/sum(g2);
    T = (mean1 + mean2)/2;
end


im1 = imread('coins.jpg');
im1 = rgb2gray(im1);
figure, imshow(im1);

im2 = blkproc(im1, [15,15], @adaptive_threshold);
figure, imshow(im2,[]);

I = imread('watershed.jpg');
I2 = rgb2gray(I);
figure, imshow(I2);

level = graythresh(I2);
bw = im2bw(I2, level);
figure, imshow(bw);

C = ~bw;
figure, imshow(C);
D = -bwdist(C);
D(C) = -Inf;

L = watershed(D);
figure, imshow(L);

wsl = label2rgb(L,'jet',[.5 .5 .5]);
figure, imshow(wsl);
I2(L==0) = 0;
figure, imshow(I2);




function [y] = adaptive_threshold(im)
 v = var(double(im(:)));
 if v < 100
     y = ones(size(im,1),size(im,2));
 else
     t = graythresh(im);
     y = im2bw(im,t);
 end
end
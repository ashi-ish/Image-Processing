% Function for LZW decompression
function [decompressed_image, decompressed_values] = lzw_decompress(compressed_data, dictionary, image_height, image_width)
    % Initialize variables
    dict_size = length(dictionary);
    next_code = dict_size + 1;
    dictionary{next_code} = [];  % Placeholder for clear code
    decompressed_image = zeros(image_height, image_width); % Initialize image matrix with zeros
    decompressed_values = [];
    
    % Handle the first code separately
    current_code = compressed_data(1);
    current_string = dictionary{current_code + 1};
    decompressed_values = [decompressed_values, current_code]; % Store numeric value
    
    % Initialize indices to fill the image matrix
    row_index = 1;
    col_index = 1;
    
    % Store the separated pixels from the first code
    for index = 1:length(current_string)
        if col_index > image_width
            col_index = 1;
            row_index = row_index + 1;
        end
        
        if row_index <= image_height
            decompressed_image(row_index, col_index) = str2double(current_string{index}); % Fill image matrix
            col_index = col_index + 1;
        end
    end
    
    % Main loop for the rest of the compressed data
    for i = 2:length(compressed_data)
        previous_code = current_code;
        current_code = compressed_data(i);
        decompressed_values = [decompressed_values, current_code]; % Store numeric value
        
        % Determine the entry from the dictionary
        if current_code + 1 <= length(dictionary)
            entry = dictionary{current_code + 1};
        elseif current_code + 1 == next_code
            entry = [current_string; current_string(1)]; % Adjust for sequence of values
        else
            error('Invalid code encountered during decompression.');
        end
        
        % Store the decoded values into decompressed_values
        decoded_value = str2double(entry{1});
        decompressed_values = [decompressed_values, decoded_value];
        
        % Fill the image matrix with decoded values
        for index = 1:length(entry)
            if col_index > image_width
                col_index = 1;
                row_index = row_index + 1;
            end
            
            if row_index <= image_height
                decompressed_image(row_index, col_index) = decoded_value; % Fill image matrix
                col_index = col_index + 1;
            end
        end
        
        % Update the dictionary
        dictionary{next_code + 1} = [current_string; entry{1}];
        next_code = next_code + 1;
        current_string = entry;
    end
end
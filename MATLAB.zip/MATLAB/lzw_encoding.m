% Clear the workspace, close all figures, and clear the command window
clearvars; close all; clc;

% Read the specified RGB image from file
originalImage = imread('udayton.jpg');

% Transform the RGB image into a grayscale image
grayscaleImage = rgb2gray(originalImage);

% Assign the grayscale image data to a variable for processing
imageMatrix = grayscaleImage;

% Apply LZW encoding to the grayscale image data
[encodedData, encodingDictionary] = lzw_compress(imageMatrix);

% Open a file for writing the encoded data in binary format
fileID = fopen('compressed_image.lzw', 'wb');
% Write the encoded data to the file using 32-bit unsigned integers
fwrite(fileID, encodedData, 'ubit32');
% Close the file to ensure data is saved
fclose(fileID);

% Create a text file to store the encoding dictionary
fileIDDict = fopen('dictionary_values.txt', 'wt');
% Iterate through the dictionary and write each key-value pair to the file
for index = 1:length(encodingDictionary)
    fprintf(fileIDDict, 'Encoded Dictionary: %d,Dictionary Entry: %s\n', index - 1, encodingDictionary{index});
end
% Close the dictionary file
fclose(fileIDDict);

% Notify the user that the compression process has finished
disp('LZW Compression completed.');

% Visualize the original and the grayscale images side by side
subplot(1, 2, 1);
imshow(originalImage);
title('Original RGB Image');

subplot(1, 2, 2);
imshow(grayscaleImage);
title('Converted Grayscale Image');
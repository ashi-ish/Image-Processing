clear all; %remove all variables in workspace
close all; %close all opening figures
clc; %clear the command window

a=[1 2 3 4 5 6 7 8 9];
b=fft(a)

c = ifft(b)

x = [ 2 3 4 5 6 7 8 1];
x1 = (-1).^[0:7].*x

X=fft(x')
X1=fft(x1')

x = [1 2 3 4];
y = [5 6 7 8];
k = fft(cconv(x,y,4)')
l = fft(x').*fft(y')
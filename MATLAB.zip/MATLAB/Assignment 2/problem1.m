% Clear workspace, close figures, and clear command window
clearvars;
close all;
clc;

% Read the image and convert it to grayscale
original_image = rgb2gray(imread('udayton.jpg'));

% Compress the grayscale image using the LZW algorithm
[compressed_data, dictionary] = lzw_compress(original_image);

% Save the compressed data and dictionary to files
save_compressed_data(compressed_data, 'compressed_image.lzw');
save_dictionary(dictionary, 'dictionary_values.txt');

% Display completion message
disp('Compression completed.');

% Function to save compressed data to a file
function save_compressed_data(data, filename)
    fid = fopen(filename, 'wb');
    fwrite(fid, data, 'ubit32'); % Write data in 32-bit format
    fclose(fid);
end

% Function to save dictionary keys and values to a text file
function save_dictionary(dictionary, filename)
    fid_dict = fopen(filename, 'wt');
    for index = 1:numel(dictionary)
        fprintf(fid_dict, 'Key: %d, Value: %s\n', index - 1, dictionary{index});
    end
    fclose(fid_dict);
end
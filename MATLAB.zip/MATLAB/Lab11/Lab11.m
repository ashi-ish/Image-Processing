clear all;
close all;
clc;

img = imread('alphabet.jpg');
img_g = rgb2gray(img);
figure, imshow(img_g), title('Gray Scale Image');

bw = imbinarize(img_g, 0.6);
figure, imshow(bw), title('Original Image');

bw_c = imcomplement(bw);
figure, imshow(bw_c), title('Complement of Original Image');

[L, num] = bwlabel(bw_c, 4);
figure, imshow(L);

fprintf('There are %d letters in the Alphabet. \n', num);

[h,w] = size(bw);
for i=1: num
    new_img = zeros(h,w);
    [r,c] = find(L == i);
    for j = 1: length(r)
        new_img(r(j),c(j)) = 1;
    end
    figure, imshow(new_img);
end

bact_img = imread('bacteria.jpg');
bact_img_g = rgb2gray(bact_img);

bact_bw = imbinarize(bact_img_g, 0.4);
figure, imshow(bact_bw), title('Original Image');

bact_bw_c = imcomplement(bact_bw);
figure, imshow(bact_bw_c), title('Complement of the Original Image');

[L, num] = bwlabel(bact_bw_c, 8);
figure,imshow(L);
fprintf('There are %d bacteria in the image.\n',num);




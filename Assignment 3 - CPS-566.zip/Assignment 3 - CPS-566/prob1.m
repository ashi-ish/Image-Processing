% Preprocessing for image 2
input_image = imread('test12.jpg');
gray_image = rgb2gray(input_image);


% Adaptive Thresholding
% So according to image one the sensitivity will 0.84
bw_text = imbinarize[gray_image, 'adaptive', 'ForegroundPolarity', 'dark', 'Sensitivity', 0.22; 

% Remove Background
bw_text = imcomplement(bw_text);
bw_text = imclearborder(bw_text);
bw_text = bwareaopen(bw_text, 100); % Remove small noise regions
bw_text = imfill(bw_text, 'holes'); % Fill holes in the text regions


% Highlighting Text
highlighted_image = input_image;
highlighted_image(repmat(~bw_text, [1 1 3])) = 255; % Set background to white

% Display Output
figure;
imshow(highlighted_image);
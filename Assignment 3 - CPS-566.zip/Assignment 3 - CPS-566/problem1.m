close all;
clear all;
clc;

% Read the input images
image_files = "test13.jpg";
num_images = length(image_files);

% Preallocate cell arrays to store processed images and their respective black background versions
processed_images_black_bg = cell(1, num_images);
grayscale_images = cell(1, num_images); % Additional array for grayscale images

for i = 1:num_images
    % Read the current input image
    current_image = imread(image_files{i});

    % Preprocess the image to enhance text detection
    I_gray = rgb2gray(current_image); % Convert the RGB image to grayscale
    grayscale_images{i} = I_gray; % Store the grayscale image
    I_gray_adjusted = imsharpen(I_gray); % Sharpen the grayscale image
    I_gray_adjusted = imadjust(I_gray_adjusted); % Adjust intensity of the grayscale image

    % Create a black background image of the same size as the original
    black_background = zeros(size(I_gray), 'uint8');

    % Detect MSER regions
    mserRegions = detectMSERFeatures(I_gray_adjusted);

    % Get the pixel list for all regions
    pixelLists = mserRegions.PixelList;

    % Extract text regions and display as white text on black background
    for j = 1:numel(pixelLists)
        % Get the coordinates of the current text region
        region_pixels = pixelLists{j};

        % Compute the bounding box of the region
        x_min = min(region_pixels(:, 1));
        x_max = max(region_pixels(:, 1));
        y_min = min(region_pixels(:, 2));
        y_max = max(region_pixels(:, 2));
        width = x_max - x_min + 1;
        height = y_max - y_min + 1;

        % Extract the text region from the adjusted grayscale image
        text_region_gray = I_gray_adjusted(y_min:y_max, x_min:x_max);

        % Use Otsu's method to find the optimal threshold and binarize the image
        threshold = graythresh(text_region_gray);  % Calculate the Otsu threshold
        text_region_binary = imbinarize(text_region_gray, threshold);  % Apply the threshold

        % Invert binary image to get white text on black background
        text_region_white = ~text_region_binary;

        % Place the white text onto the black background
        black_background(y_min:y_max, x_min:x_max) = text_region_white * 255;
    end

    % Store the black background images
    processed_images_black_bg{i} = black_background;
end

% Display the black background versions with white text
figure('Position', [100, 100, 2400, 800]);
for i = 1:num_images
    subplot(1, num_images, i);
    imshow(processed_images_black_bg{i});
    title(sprintf('White Text on Black Background %d', i));
end

